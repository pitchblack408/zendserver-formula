The MongoDB plugin provides information about queries and commands using new php mongoDB drivers.
It will be compatible with PHP7.

- **Plugin:**
    *   See read queries using sort, limit and skip
    *   See write queries using update, insert and remove and theres options
    *   See your Db commands details.
